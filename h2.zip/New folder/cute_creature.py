import random

class CuteCreature:

    def __init__(self, species, max_hp, attack, defense, xp_value, is_special):
        ##initialize a new CuteCreature at lvl 1 & full HP and zero experience."""
        self.species = species
        self.level = 1
        self.max_hp = max_hp
        self.current_hp = max_hp
        self.attack_rating = attack
        self.defense_rating = defense
        self.xp = 0
        self.xp_value = xp_value
        self.is_special = is_special

    def __str__(self):
        #calculate XP for next level
        xp_needed = self._xp_for_next_level()
        special_line = "*** Special! ***\n" if self.is_special else ""
        return (
            f"Level {self.level} {self.species}\n"
            f"{'-' * (len(self.species) + len(str(self.level)) + 7)}\n"
            f"{special_line}"
            f"HP: {self.current_hp}/{self.max_hp}\n"
            f"ATK: {self.attack_rating}\n"
            f"DEF: {self.defense_rating}\n"
            f"XP: {self.xp}/{xp_needed}\n"
            f"XP Val: {self.xp_value}"
        )

    def _xp_for_next_level(self):
        #XP needed grows by 75 per level
        total = 0
        for lvl in range(1, self.level + 1):
            total += 200 + (lvl - 1) * 75
        return total

    def level_up(self):
        self.level += 1
        print(f"{self.species} leveled up to level {self.level}!")

        #stat increases based on new level
        if 2 <= self.level <= 9:
            self.max_hp += 7
            self.attack_rating += 3
            self.defense_rating += 3
        else:
            #10 and above
            self.max_hp += 2
            self.attack_rating += 1
            self.defense_rating += 1

        self.xp_value += 25
        self.current_hp = self.max_hp

    def gain_xp(self, amount):
        print(f"{self.species} gained {amount} XP!")
        self.xp += amount

        #keep leveling up as long as have enough XP
        while self.xp >= self._xp_for_next_level():
            self.level_up()

    def take_damage(self, amount):
        self.current_hp -= amount
        if self.current_hp < 0:
            self.current_hp = 0
        print(f"{self.species} took {amount} damage! (HP: {self.current_hp}/{self.max_hp})")

        #if creature has been knocked out
        if self.current_hp == 0:
            print(f"{self.species} has been incapacitated!")

    def attack(self, target):
        print(f"\n{self.species} attacks {target.species}!")

        roll = random.random()

        if roll < 0.70:
            damage = max(1, self.attack_rating - target.defense_rating)
            print(f"Hit! Deals {damage} damage.")
            target.take_damage(damage)

        elif roll < 0.80:
            damage = max(2, (self.attack_rating - target.defense_rating) * 2)
            print(f"Critical hit! Deals {damage} damage!")
            target.take_damage(damage)

        else:
            #miss
            print("Miss! No damage dealt.")

        if target.current_hp == 0:
            print(f"{target.species} was defeated! {self.species} gains {target.xp_value} XP.")
            self.gain_xp(target.xp_value)

# test
if __name__ == "__main__":
    print("=" * 50)
    print("CUTE CREATURE BATTLE TEST")
    print("=" * 50)

    #create two creatures
    creature1 = CuteCreature("Bowlbasore", 45, 8, 4, 80, False)
    creature2 = CuteCreature("Peekashoe", 35, 10, 3, 90, True)

    print(creature1)
    print()
    print(creature2)
    print()

    print("=" * 50)
    print("BATTLE START!")
    print("=" * 50)

    #alternate attacks
    turn = 0
    while creature1.current_hp > 0 and creature2.current_hp > 0:
        if turn % 2 == 0:
            creature1.attack(creature2)
        else:
            creature2.attack(creature1)
        turn += 1

    print("\n" + "=" * 50)
    print("BATTLE OVER!")
    if creature1.current_hp > 0:
        print(f"{creature1.species} wins!")
        print(creature1)
    else:
        print(f"{creature2.species} wins!")
        print(creature2)
