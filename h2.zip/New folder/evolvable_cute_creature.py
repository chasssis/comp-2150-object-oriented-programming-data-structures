from cute_creature import CuteCreature

class EvolvableCuteCreature(CuteCreature):
    _LETTER_TO_TYPE = {}
    for ch in "abcdef":    _LETTER_TO_TYPE[ch] = "light"
    for ch in "ghijkl":    _LETTER_TO_TYPE[ch] = "dark"
    for ch in "mnopqr":    _LETTER_TO_TYPE[ch] = "nature"
    for ch in "stuvwxyz":  _LETTER_TO_TYPE[ch] = "tech"

    # resistance and vulnerability tables
    _RESISTANT_TO = {
        "light":  "tech",
        "dark":   "nature",
        "nature": "dark",
        "tech":   "light",
    }
    _VULNERABLE_TO = {
        "light":  "dark",
        "dark":   "light",
        "nature": "tech",
        "tech":   "nature",
    }

    def __init__(self, species, max_hp, attack, defense, xp_value, is_special,
                 evolve_level, evolved_species):
        #set all base attributes
        super().__init__(species, max_hp, attack, defense, xp_value, is_special)
        self.evolve_level = evolve_level
        self.evolved_species = evolved_species
        self.creature_type = None 

    def __str__(self):
        xp_needed = self._xp_for_next_level()
        special_line = "*** Special! ***\n" if self.is_special else ""
        type_line = f"Type: {self.creature_type}\n" if self.creature_type else "Type: None\n"
        return (
            f"Level {self.level} {self.species}\n"
            f"{'-' * (len(self.species) + len(str(self.level)) + 7)}\n"
            f"{special_line}"
            f"{type_line}"
            f"HP: {self.current_hp}/{self.max_hp}\n"
            f"ATK: {self.attack_rating}\n"
            f"DEF: {self.defense_rating}\n"
            f"XP: {self.xp}/{xp_needed}\n"
            f"XP Val: {self.xp_value}"
        )

    def level_up(self):
        super().level_up()

        #check for evolution
        if self.level == self.evolve_level and self.creature_type is None:
            print(f"*** {self.species} is evolving into {self.evolved_species}! ***")
            self.species = self.evolved_species

            #determine type
            first_letter = self.species[0].lower()
            self.creature_type = self._LETTER_TO_TYPE.get(first_letter, "light")
            print(f"*** {self.species} is now attuned to the {self.creature_type} type! ***")

    def special_attack(self, target):
        if self.creature_type is None:
            print(f"{self.species} hasn't evolved yet and cannot use a special attack!")
            return

        print(f"\n{self.species} uses a special attack on {target.species}!")

        #determine target's type
        target_type = getattr(target, "creature_type", None)

        #calculate damage
        A = self.attack_rating
        D = target.defense_rating

        if target_type == self.creature_type:
            damage = 0
            print(f"Same type — the special attack has no effect!")

        elif target_type is not None and target_type == self._RESISTANT_TO.get(self.creature_type):
            damage = max(0, A - 5 * D)
            print(f"{target.species}'s {target_type} type resists {self.creature_type}!")

        elif target_type is not None and target_type == self._VULNERABLE_TO.get(self.creature_type):
            damage = max(10, 5 * A - D)
            print(f"{target.species}'s {target_type} type is vulnerable to {self.creature_type}!")

        else:
            damage = max(1, A - D)

        if damage > 0:
            print(f"Special attack deals {damage} damage.")
            target.take_damage(damage)
        else:
            print("Special attack dealt 0 damage.")

        #award XP if target
        if target.current_hp == 0:
            print(f"{target.species} was defeated! {self.species} gains {target.xp_value} XP.")
            self.gain_xp(target.xp_value)

#tests for evo
if __name__ == "__main__":
    def section(title):
        print("\n" + "=" * 55)
        print(f"  {title}")
        print("=" * 55)

    #evo
    section("TEST 1: Evolution")

    tore = EvolvableCuteCreature("Tore-Chick", 40, 12, 5, 80, False, 3, "Calmbustkin")
    print(tore)
    #enough XP to reach level 3
    tore.gain_xp(475)
    print()
    print(tore)

    squa = EvolvableCuteCreature("Squaretell", 35, 10, 6, 70, True, 2, "Magnorvex")
    squa.gain_xp(200)   #level 2 > evolution
    print()
    print(squa)

    peek = EvolvableCuteCreature("Peekashoe", 38, 11, 4, 75, False, 2, "Stormfang")
    peek.gain_xp(200)
    print()
    print(peek)

    bowl = EvolvableCuteCreature("Bowlbasore", 42, 15, 3, 85, False, 2, "Grimshade")
    bowl.gain_xp(200)
    print()
    print(bowl)

    #same-type SpAtk
    section("TEST 2: Same type (Calmbustkin light vs Eckanz light)")
    eckanz = EvolvableCuteCreature("Eckanz", 40, 5, 3, 70, True, 2, "Arclyte")
    eckanz.gain_xp(200) 
    print(eckanz)
    tore.special_attack(eckanz)

    #resistant type
    section("TEST 3: Resistant type (nature Magnorvex vs dark Grimshade)")
    squa.special_attack(bowl)

    #vulnerable type
    section("TEST 4: Vulnerable type (nature Magnorvex vs tech Stormfang)")
    squa.special_attack(peek)

    #evolved vs unevolved
    section("TEST 5: Evolved vs unevolved EvolvableCuteCreature")
    unevolved = EvolvableCuteCreature("Frostling", 30, 8, 5, 60, False, 5, "Nyvermast")
    print(unevolved)
    tore.special_attack(unevolved)

    #evolved vs regular
    section("TEST 6: Evolved vs regular CuteCreature")
    regular = CuteCreature("Squartle", 30, 7, 6, 65, False)
    print(regular)
    tore.special_attack(regular)

    #unevolved use SpAtk
    section("TEST 7: Unevolved creature tries special attack")
    unevolved.special_attack(regular)
